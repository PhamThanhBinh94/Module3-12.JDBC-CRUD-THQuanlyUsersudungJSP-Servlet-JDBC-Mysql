create
    definer = root@localhost procedure editProducts(IN id1 int, IN productCode1 varchar(50),
                                                    IN productName1 varchar(50), IN productPrice1 double,
                                                    IN productAmount1 int, IN productDescription1 varchar(200),
                                                    IN productStatus1 bit)
begin
   update Products
        set productCode = productCode1,
            productName = productName1,
            productPrice = productPrice1,
            productAmount = productAmount1,
            productDescription = productDescription1,
            productStatus = productStatus1
        where Products.id = id1;
end;

